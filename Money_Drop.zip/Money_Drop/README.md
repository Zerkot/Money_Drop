# Money_Drop

Lien UML : https://lucid.app/lucidchart/69a1a1b5-9698-451f-928f-24ea8305e941/edit?viewport_loc=3485%2C504%2C2466%2C1196%2CHWEp-vi-RSFO&invitationId=inv_10f5c6f4-f341-4bdc-8131-57269cafea2b
